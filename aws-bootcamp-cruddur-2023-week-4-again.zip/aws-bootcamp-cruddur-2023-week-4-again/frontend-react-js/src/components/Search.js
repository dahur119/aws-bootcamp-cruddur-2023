import './Search.css';

export default function ActivityFeed(props) {
  return (
    <div className='search_field'>
      <input type='text' placeholder='Search Cruddur' />
    </div>
  );
}